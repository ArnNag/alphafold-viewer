import './index.html';
import './favicon.ico';
require('./skin/rcsb.scss');
